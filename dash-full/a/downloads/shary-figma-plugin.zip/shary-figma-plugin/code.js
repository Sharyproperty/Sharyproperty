// «بلجن شاري» — runs inside Figma. Draws the agent's designs (their «spec», the same drawing the dashboard draws) as real, editable layers:
// a frame of the design's size, the photo as an image fill, the shapes, the words in an auto-layout stack (Cairo, bold, right to left),
// the logo. Then it exports the frame as PNG for the dashboard. The panel (ui.html) talks to the dashboard; this file never goes online.

var PAGE = 'شاري — تصميمات الإيجنت';
var STORE = 'shary-agent-settings';

figma.showUI(__html__, { width: 380, height: 640, themeColors: true });

function hex(color, alpha) {
  var value = String(color || '#000000').replace('#', '');
  if (value.length === 3) { value = value.replace(/(.)/g, '$1$1'); }
  var n = parseInt(value, 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255, a: alpha === undefined ? 1 : alpha };
}
function solid(color, opacity) {
  var c = hex(color);
  return { type: 'SOLID', color: { r: c.r, g: c.g, b: c.b }, opacity: opacity === undefined ? 1 : opacity };
}
// a linear gradient as in CSS (0 = towards the top, 90 = towards the right …): the transform maps the node's box to the gradient line
function gradient(fill) {
  var angle = (fill.angle || 0) * Math.PI / 180;
  var dx = Math.round(Math.sin(angle) * 1000) / 1000;
  var dy = Math.round(-Math.cos(angle) * 1000) / 1000;
  return {
    type: 'GRADIENT_LINEAR',
    gradientTransform: [[dx, dy, 0.5 - 0.5 * (dx + dy)], [-dy, dx, 0.5 + 0.5 * (dy - dx)]],
    gradientStops: (fill.stops || []).map(function (stop) { return { position: Math.max(0, Math.min(1, stop[2])), color: hex(stop[0], stop[1]) }; })
  };
}

var fontCache = {};
async function font(weight) {
  var style = weight >= 800 ? 'ExtraBold' : (weight >= 700 ? 'Bold' : 'SemiBold');
  if (fontCache[style]) { return fontCache[style]; }
  var tries = [{ family: 'Cairo', style: style }, { family: 'Cairo', style: 'Bold' }, { family: 'Inter', style: 'Bold' }];
  for (var i = 0; i < tries.length; i++) {
    try { await figma.loadFontAsync(tries[i]); fontCache[style] = tries[i]; return tries[i]; } catch (error) { /* the next one */ }
  }
  throw new Error('no font');
}

async function text(item, align) {
  var node = figma.createText();
  node.fontName = await font(item.weight || 800);
  node.characters = String(item.text || '');
  node.fontSize = item.size;
  node.fills = [solid(item.color || '#FFFFFF', item.opacity)];
  node.textAlignHorizontal = align === 'center' ? 'CENTER' : (align === 'left' ? 'LEFT' : 'RIGHT');
  node.lineHeight = { value: Math.round((item.lh || 1.3) * 100), unit: 'PERCENT' };
  node.name = item.id || 'text';
  return node;
}

async function pill(item) {
  var box = figma.createFrame();
  box.name = item.id || 'pill';
  box.layoutMode = 'HORIZONTAL';
  box.primaryAxisSizingMode = 'AUTO';
  box.counterAxisSizingMode = 'AUTO';
  box.primaryAxisAlignItems = 'CENTER';
  box.counterAxisAlignItems = 'CENTER';
  var padX = Math.round(item.size * (item.pad || 0.9));
  var padY = Math.round(item.size * 0.42);
  box.paddingLeft = padX; box.paddingRight = padX; box.paddingTop = padY; box.paddingBottom = padY;
  box.cornerRadius = item.size * 2;
  box.fills = [solid(item.fill || '#E8A838')];
  var label = await text({ text: item.text, size: item.size, weight: item.weight || 800, color: item.color || '#10263F', lh: 1.1 }, 'center');
  label.name = (item.id || 'pill') + ' text';
  box.appendChild(label);
  return box;
}

async function stack(layer) {
  var box = figma.createFrame();
  box.name = 'words';
  box.fills = [];
  box.clipsContent = false;
  box.layoutMode = 'VERTICAL';
  box.primaryAxisSizingMode = 'FIXED';
  box.counterAxisSizingMode = 'FIXED';
  box.resize(Math.max(1, layer.w), Math.max(1, layer.h));
  box.x = layer.x; box.y = layer.y;
  box.itemSpacing = layer.gap || 16;
  box.primaryAxisAlignItems = layer.valign === 'middle' ? 'CENTER' : (layer.valign === 'bottom' ? 'MAX' : 'MIN');
  box.counterAxisAlignItems = layer.align === 'center' ? 'CENTER' : (layer.align === 'left' ? 'MIN' : 'MAX');
  var items = (layer.items || []).filter(function (item) { return String(item.text || '').trim() !== ''; });
  for (var i = 0; i < items.length; i++) {
    var item = items[i];
    if (item.type === 'pill') {
      box.appendChild(await pill(item));
      continue;
    }
    var node = await text(item, layer.align);
    box.appendChild(node);
    node.layoutSizingHorizontal = 'FILL';
    node.textAutoResize = 'HEIGHT';
    node.setPluginData('size', String(item.size));
    // smaller until it fits its lines (like the dashboard's drawing)
    var size = item.size;
    var most = size * (item.lh || 1.3) * (item.max_lines || 3) * 1.06;
    var guard = 0;
    while (node.height > most && size > 12 && guard < 10) {
      size = Math.round(size * 0.92);
      node.fontSize = size;
      most = size * (item.lh || 1.3) * (item.max_lines || 3) * 1.06;
      guard++;
    }
  }
  // everything smaller together until the words fit their box (the same rule as the dashboard's drawing)
  var fitRound = 0;
  var used = function () { return box.children.reduce(function (sum, child) { return sum + child.height; }, 0) + box.itemSpacing * Math.max(0, box.children.length - 1); };
  while (used() > layer.h && fitRound < 8) {
    box.itemSpacing = Math.round(box.itemSpacing * 0.9);
    box.findAll(function (node) { return node.type === 'TEXT'; }).forEach(function (node) { node.fontSize = Math.max(12, Math.round(node.fontSize * 0.9)); });
    box.findAll(function (node) { return node.type === 'FRAME' && node.layoutMode === 'HORIZONTAL'; }).forEach(function (frame) {
      frame.paddingLeft = Math.round(frame.paddingLeft * 0.9); frame.paddingRight = Math.round(frame.paddingRight * 0.9);
      frame.paddingTop = Math.round(frame.paddingTop * 0.9); frame.paddingBottom = Math.round(frame.paddingBottom * 0.9);
    });
    fitRound++;
  }
  return box;
}

async function brand(layer, assets) {
  if (assets.logoSvg) {
    var svg = figma.createNodeFromSvg(assets.logoSvg);
    var k = Math.min(layer.w / svg.width, layer.h / svg.height);
    svg.resize(svg.width * k, svg.height * k);
    svg.x = layer.align === 'left' ? layer.x : layer.x + layer.w - svg.width;
    svg.y = layer.y + (layer.h - svg.height) / 2;
    svg.name = 'logo';
    return svg;
  }
  if (assets.logo) {
    var image = figma.createImage(assets.logo);
    var size = await image.getSizeAsync();
    var scale = Math.min(layer.w / size.width, layer.h / size.height);
    var rect = figma.createRectangle();
    rect.resize(Math.max(1, size.width * scale), Math.max(1, size.height * scale));
    rect.x = layer.align === 'left' ? layer.x : layer.x + layer.w - rect.width;
    rect.y = layer.y + (layer.h - rect.height) / 2;
    rect.fills = [{ type: 'IMAGE', imageHash: image.hash, scaleMode: 'FIT' }];
    rect.name = 'logo';
    return rect;
  }
  // Shary's mark and its name
  var group = [];
  var r = layer.h / 2;
  var mark = figma.createEllipse(); mark.resize(r * 2, r * 2); mark.fills = [solid('#123A5C')];
  var gold = figma.createEllipse(); gold.resize(r * 0.68, r * 0.68); gold.fills = [solid('#E8A838')];
  var teal = figma.createEllipse(); teal.resize(r * 0.76, r * 0.76); teal.fills = [solid('#2A9D8F')];
  var name = await text({ text: layer.lang === 'en' ? 'Shary' : 'شاري', size: Math.round(layer.h * 0.62), weight: 800, color: layer.color || '#FFFFFF', lh: 1.1 }, 'left');
  name.textAutoResize = 'WIDTH_AND_HEIGHT';
  var total = r * 2 + layer.h * 0.25 + name.width;
  var start = layer.align === 'left' ? layer.x : layer.x + layer.w - total;
  var markX = layer.lang === 'en' ? start : start + total - r * 2;
  mark.x = markX; mark.y = layer.y;
  gold.x = markX + r * 0.6 - r * 0.34; gold.y = layer.y + r * 0.6 - r * 0.34;
  teal.x = markX + r * 1.4 - r * 0.38; teal.y = layer.y + r * 1.24 - r * 0.38;
  name.x = layer.lang === 'en' ? start + r * 2 + layer.h * 0.25 : start;
  name.y = layer.y + (layer.h - name.height) / 2;
  mark.name = 'logo mark'; gold.name = 'logo dot'; teal.name = 'logo dot'; name.name = 'logo name';
  group.push(mark, gold, teal, name);
  return group;
}

async function page() {
  await figma.loadAllPagesAsync();
  var found = figma.root.children.filter(function (one) { return one.name === PAGE; })[0];
  if (!found) { found = figma.createPage(); found.name = PAGE; }
  await figma.setCurrentPageAsync(found);
  return found;
}

// to the right of the earlier versions of the same design, else under everything on the page
function place(frame, where, root) {
  var mine = where.children.filter(function (node) {
    try { return JSON.parse(node.getPluginData('shary') || '{}').root === root; } catch (error) { return false; }
  });
  if (mine.length) {
    var last = mine.reduce(function (a, b) { return a.x + a.width > b.x + b.width ? a : b; });
    frame.x = last.x + last.width + 120;
    frame.y = last.y;
    return;
  }
  var bottom = where.children.reduce(function (most, node) { return node === frame ? most : Math.max(most, node.y + node.height); }, -200);
  frame.x = 0;
  frame.y = bottom + 200;
}

async function draw(design, assets) {
  var spec = design.spec;
  var where = await page();
  var frame = figma.createFrame();
  frame.name = '#' + design.id + ' · نسخة ' + design.version + ' — ' + design.title;
  frame.resize(spec.w, spec.h);
  frame.fills = [solid(spec.bg || '#0F2D4A')];
  frame.clipsContent = true;
  where.appendChild(frame);
  place(frame, where, design.root);
  var layers = spec.layers || [];
  for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    var node = null;
    if (layer.type === 'rect') {
      node = figma.createRectangle();
      node.resize(Math.max(1, layer.w), Math.max(1, layer.h));
      node.x = layer.x; node.y = layer.y;
      node.cornerRadius = layer.radius || 0;
      node.fills = [typeof layer.fill === 'object' && layer.fill ? gradient(layer.fill) : solid(layer.fill || '#000000')];
      if (layer.opacity !== undefined) { node.opacity = layer.opacity; }
    } else if (layer.type === 'image') {
      node = figma.createRectangle();
      node.resize(Math.max(1, layer.w), Math.max(1, layer.h));
      node.x = layer.x; node.y = layer.y;
      node.cornerRadius = layer.radius || 0;
      var bytes = layer.src === 'logo' ? assets.logo : assets.photo;
      node.fills = bytes ? [{ type: 'IMAGE', imageHash: figma.createImage(bytes).hash, scaleMode: layer.fit === 'contain' ? 'FIT' : 'FILL' }] : [solid('#C9D2DE')];
    } else if (layer.type === 'stack') {
      node = await stack(layer);
    } else if (layer.type === 'brand') {
      node = await brand(layer, assets);
    }
    if (!node) { continue; }
    (Array.isArray(node) ? node : [node]).forEach(function (one) { if (!one.name || one.name === 'Rectangle' || one.name === 'Frame') { one.name = layer.id || layer.type; } frame.appendChild(one); });
  }
  frame.setPluginData('shary', JSON.stringify({ id: design.id, root: design.root, version: design.version }));
  return frame;
}

async function find(id) {
  var where = await page();
  return where.children.filter(function (node) {
    try { return JSON.parse(node.getPluginData('shary') || '{}').id === id; } catch (error) { return false; }
  })[0] || null;
}

async function exportPng(node) {
  return node.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: 1 } });
}

figma.ui.onmessage = async function (message) {
  try {
    if (message.type === 'init') {
      var saved = (await figma.clientStorage.getAsync(STORE)) || {};
      figma.ui.postMessage({ type: 'state', saved: saved, fileKey: figma.fileKey || '' });
    } else if (message.type === 'save') {
      await figma.clientStorage.setAsync(STORE, message.saved || {});
    } else if (message.type === 'draw') {
      var frame = await draw(message.design, message.assets || {});
      figma.viewport.scrollAndZoomIntoView([frame]);
      figma.currentPage.selection = [frame];
      figma.ui.postMessage({ type: 'drawn', id: message.design.id, node: frame.id, fileKey: figma.fileKey || '' });
      figma.ui.postMessage({ type: 'exported', id: message.design.id, png: await exportPng(frame) });
    } else if (message.type === 'export') {
      var existing = await find(message.id);
      if (!existing) { figma.ui.postMessage({ type: 'error', id: message.id, text: 'التصميم مش موجود في الملف ده — ارسمه الأول.' }); return; }
      figma.ui.postMessage({ type: 'exported', id: message.id, png: await exportPng(existing), mine: true });
    } else if (message.type === 'show') {
      var shown = await find(message.id);
      if (shown) { figma.viewport.scrollAndZoomIntoView([shown]); figma.currentPage.selection = [shown]; }
    } else if (message.type === 'has') {
      var ids = [];
      var where = await page();
      where.children.forEach(function (node) { try { var data = JSON.parse(node.getPluginData('shary') || '{}'); if (data.id) { ids.push(data.id); } } catch (error) { /* not ours */ } });
      figma.ui.postMessage({ type: 'has', ids: ids });
    } else if (message.type === 'notify') {
      figma.notify(String(message.text || ''));
    } else if (message.type === 'open' && /^https:\/\//.test(String(message.url || ''))) {
      figma.openExternal(String(message.url));
    }
  } catch (error) {
    figma.ui.postMessage({ type: 'error', id: message.design ? message.design.id : message.id, text: String(error && error.message || error) });
  }
};
